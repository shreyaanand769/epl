const clubs = [
  { name: "Manchester United", captain: "Bruno Fernandes", points: 68 },
  { name: "Manchester City", captain: "Kevin De Bruyne", points: 92 },
  { name: "Liverpool", captain: "Virgil van Dijk", points: 85 },
  { name: "Chelsea", captain: "Reece James", points: 76 }
];

const clubList = document.getElementById("club-list");
const clubDetails = document.getElementById("club-details");

clubs.forEach(club => {
  const div = document.createElement("div");
  div.className = "club-name";
  div.innerText = club.name;
  div.onclick = () => {
    clubDetails.innerHTML = `
      <h2>${club.name}</h2>
      <p><strong>Captain:</strong> ${club.captain}</p>
      <p><strong>Points:</strong> ${club.points}</p>
    `;
  };
  clubList.appendChild(div);
});
